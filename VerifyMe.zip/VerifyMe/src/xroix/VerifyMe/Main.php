<?php
//created by XROIXHD,
//discord: XroixHD#2106
namespace xroix\VerifyMe;

use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\scheduler\Task;

class Main extends PluginBase {

    /** @var Config */
    public $cfg;

    public $task;

    /** Bot Status Vars */
    public $running_bot = FALSE;

    public function onDisable() {
        if (\file_exists($this->getDataFolder()."storage.php")) {
            $file = file($this->getDataFolder()."storage.php");
            file_put_contents($this->getDatafolder()."storage.php", "<?php $"."data = arr"."ay(".");");
        }
        $this->getLogger()->info("Plugin wurde erfolgreich deaktiviert!");
    }

    public function onEnable() {
        $this->task = new TaskX($this);
        $this->getScheduler()->scheduleDelayedRepeatingTask($this->task, 100, 100);
        @mkdir($this->getDataFolder());
        if(!file_exists($this->getDataFolder()."config.yml")) {
            $this->set_cfg();
        } else {
            $this->cfg = new Config($this->getDataFolder()."config.yml", Config::YAML);
            $file = file($this->getDataFolder()."storage.php");
            file_put_contents($this->getDatafolder()."storage.php", "<?php $"."data = arr"."ay(".");"); 
        }
        $this->getLogger()->info("Plugin wurde geladen!");
        
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) :bool {
        if ($command == "verify") {

            if (empty($args[0])) {
                $sender->sendMessage("Praxis: /verify help");
                return TRUE;
            }

            switch (strtolower($args[0])) {

                case ("get"):
                    if(!$sender instanceof Player){$sender->sendMessage("[ERROR] Nur Spieler können diesen Befehl ausführen!");return TRUE;}
                    $this->set_entry($sender->getName(), $sender);
                    return TRUE;
                    break;

                case ("help"):
                    if ($sender->hasPermission("verifyme.admin")) {
                        $sender->sendMessage("[Verify] /verify get || Bekomme einen Key!");
                        $sender->sendMessage("         /verify bot <start/stop> || Starte/Schließe den Bot!");
                        return TRUE;
                    } else {
                        $sender->sendMessage("[Verify] /verify get || Bekomme einen Key!");
                        return TRUE;
                    }
                    break;
        
                case ("bot"):
                    if (!$sender->hasPermission("verifyme.admin")) {
                        $sender->sendMessage("[Verify] Du hast eine fehlende Berechtigung!");
                        return TRUE;
                    } elseif (empty($args[1])) {
                        $sender->sendMessage("Praxis: /verify bot <start/stop>");
                        return TRUE;
                    } elseif(strtolower($args[1]) == "start") {
                        global $running_bot;
                        if($this->cfg->get("TOKEN")=="none"){
                            $sender->sendMessage("[ERROR] Bitte setzen Sie den TOKEN in der Config!");
                            return TRUE;
                        }
                        if ($running_bot) {
                            $sender->sendMessage("[ERROR] Bot wurde schon gestartet!");
                            return TRUE;
                        } else {
                            $running_bot = TRUE;
                        }
                        $comando = "php ".dirname(__FILE__)."\bot.php ".$this->cfg->get("TOKEN")." ".$this->getDataFolder()." ".$this->cfg->get("role_name");
                        if (substr(php_uname(), 0, 7) == "Windows"){ 
                            pclose(popen("start cmd /K ". $comando, "r"));  
                        } else { 
                            exec("screen -S discordBot" . " > /dev/null &");   
                        } 
                        $sender->sendMessage("[Verify] Bot wurde gestartet!");
                        return TRUE;
                    } elseif(strtolower($args[1]) == "stop") {
                        global $running_bot;
                            if ($running_bot) { if (substr(php_uname(), 0, 7) == "Windows"){ 
                                //@Todo Windows stop 
                            } else { 
                                exec("screen -S discordBot -X quits" . " > /dev/null &");   
                            } 
                            $running_bot = FALSE;
                            $sender->sendMessage("[Verify] Bot wurde geschlossen!");
                        } else {
                            $sender->sendMessage("[Verify] Bot wurde noch nicht gestartet!");
                        }
                        return TRUE;
                    }
                    $sender->sendMessage("Praxis: /verify bot <start/stop>");
                    return TRUE;
                    break;

                default:
                    $sender->sendMessage("Praxis: /verify help");
                    return TRUE;
                    break;
        
            }
        
        }
    }
############################### FUNCTIONS ##############################
    public function set_cfg() {
        $this->cfg = new Config($this->getDataFolder()."config.yml", Config::YAML);
        $this->cfg->set("TOKEN", "none");
        $this->cfg->set("role_name", "verified");
        $data = array();
        file_put_contents($this->getDataFolder()."storage.php", '<?php $data = ' . var_export($data, true) . ";");
        $this->cfg->save();
    }

    function generate_number(array $kes, $kes1) {
        $num = mt_rand(1984,9869);
        if (empty($key)) {
            return $num;
        } else {
            while (array_key_exists($num, $kes) || array_key_exists($num, $kes1)) {
                $num = mt_rand(1984,9869);
            }
        }
        return $num;
    }

    public function array_dict_push($ar, $key, $value) {
        
        $keys = array_keys($ar);
        if (in_array($key, $keys)) { return;}
        array_push($keys, $key);

        $values = array_values($ar);
        array_push($values, $value);

        $ar = array_combine($keys, $values);
        return $ar;
    }

    public function in_multi_array($word, array $ar) {
        $count = 0;
        $places = array();
        foreach ($ar as $v) {
            if (is_array($v)) {
                foreach ($v as $x) {
                    if ($x == $word) {
                        return TRUE;
                    }
                }
            } elseif ($v == $word) {
                return TRUE;
            }
            
        }
        return FALSE;
    }
        

    function set_entry($name, $sender) {
        require $this->getDataFolder()."storage.php";
        a:
        if ($this->task->inter == TRUE) {
            goto a;
        }
        elseif (array_key_exists($name, $this->task->task_list)) {
            $sender->sendMessage("[ERROR] Der Name ist noch in der Liste!");
            return;
        } elseif(in_array($name, $data)) {
            $sender->sendMessage("[ERROR] Der Name ist noch in der Liste!");
            return;
        }
        $key = $this->generate_number($data, $this->task->task_list) or die($sender->sendMessage("[ERROR] Ein Fehler ist aufgetreten, versuchen sie es erneut!"));
        $this->task->task_list = $this->array_dict_push($this->task->task_list, $name, array($key, "none")) or die($sender->sendMessage("[ERROR] Ein Fehler ist aufgetreten, versuchen sie es erneut!"));
        $sender->sendMessage("[Verify] Dein Key lautet: ".$key);
        return;
    }
}