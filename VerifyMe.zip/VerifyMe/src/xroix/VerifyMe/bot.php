<?php
include __DIR__.'/vendor/autoload.php';

use Discord\DiscordCommandClient;
use Discord\Http\http;
use Discord\Discord;

class bot {
    public $discord;
    public $used_names;
    public $role_name;
    public $data_f;

    function __construct($token, $datafolder, $rolec) {
        global $discord;
        $this->data_f = $datafolder;
        $this->role_name=$rolec;
        $this->used_names=array();
        $discord = new DiscordCommandClient([
            'token' => $token,
            "prefix" => "/",
            "defaultHelpCommand" => "false",
            "description" => "made for the german MCBE Server Die Praxis!",
            "discordOptions" => ['disabledEvents' => [
                    'PRESENCE_UPDATE'
                ]]
        ]);

        $discord->on('ready', function ($discord) {
            global $role_name;
            echo "Bot ist bereit! ".$role_name, PHP_EOL;
        });

        $discord->registerCommand('verify', function ($message, $params) {
            require $this->data_f."storage.php";
            global $role_name;

            if (empty($params[0])) {
                $message->channel->sendMessage("**Praxis:** `/verify help`")->then(function(){});

            } elseif($params[0] == "help") {
                $message->channel->sendMessage("**[**`Verify`**]**  /verify set <key> || Bekomme diesen Key Ingame, /verify get!")->then(function(){});

            } elseif($params[0] == "set") {
                if (empty($params[1])) {
                    $message->channel->sendMessage("**Praxis:**  /verify set <key>")->then(function(){});
                } elseif(empty($data)) { 
                    $message->channel->sendMessage("**[**`Verify`**]**  Liste ist leer!")->then(function(){});
                } else {
                    $author = $message->author;
                    $member = $message->channel->guild->members->get("id", $author->id);
                    $key = $params[1];

                    if (array_key_exists($key, $data)) {

                        if (in_array($member->username, $this->used_names)) {
                            $message->channel->sendMessage("**[**`Verify`**]**  Dieser Name wurde bereits verwendet!");
                            return;
                        } else {
                            array_push($this->used_names, $member->username);
                        }

                        $member->setNickname($data[$key])->then(function () {});
                        
                        $role = $message->channel->guild->roles->get("name", $role_name);
                        $message->channel->deleteMessages([$message])->then(function () {});
                        $roleid = (int) filter_var($message->channel->guild->roles->get("name", $role_name), FILTER_SANITIZE_NUMBER_INT);;
                            $curl = curl_init();
                            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, TRUE);
                            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                            curl_setopt_array($curl, array(
                                CURLOPT_URL => "https://discordapp.com/api/guilds/340533666973483011/members/".$member->id."/roles/575718518687793176",
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_ENCODING => "",
                                CURLOPT_MAXREDIRS => 10,
                                CURLOPT_TIMEOUT => 30,
                                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                CURLOPT_CUSTOMREQUEST => "PUT",
                                CURLOPT_POSTFIELDS => "",
                                CURLOPT_HTTPHEADER => array(
                                    "Accept: */*",
                                    "Authorization: Bot NTY2MzAxMzY2NTgzMDMzODc3.XM8L6Q.PyKU0a04NnyVtyyip_wJLAAv-Tw",
                                    "Cache-Control: no-cache",
                                    "Connection: keep-alive",
                                    "Content-Type: application/json",
                                    "Host: discordapp.com",
                                    "accept-encoding: gzip, deflate",
                                    "cache-control: no-cache",
                                    "content-length: 0",
                                    "cookie: __cfduid=d7225794c1c3efc4fdc086336bb90ca501552400270"
                                ),
                            ));
                            $response = curl_exec($curl);
                            $err = curl_error($curl);

                            curl_close($curl);
                            echo $roleid;
                            if ($err) {
                                echo "cURL Error #:" . $err;
                            } else {
                                echo $response;
                            }
                        $message->channel->sendMessage("**[**`Verify`**]**  Du hast du dich erfolgreich mit ".$data[$key]." verknüpft! \n                    Falscher Account? Wende dich an den Support oder versuch es erneut!")->then(function(){});
                    } else {
                        $message->channel->sendMessage("**[**`Verify`**]**  Dieser Key existiert nicht!")->then(function(){});
                    }
                }
            }
        }, [
            'description' => 'Verify Command',
        ]);

        $discord->run();
    }
    public function disable_bot() {
        $discord->close();
    }
}

$bot = new bot($argv[1], $argv[2], $argv[3]);