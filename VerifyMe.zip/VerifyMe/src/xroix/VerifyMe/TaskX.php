<?php
//created by XROIXHD,
//discord: XroixHD#2106
namespace xroix\VerifyMe;

use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\Task;
use pocketmine\plugin\Plugin;
use pocketmine\Player;
use pocketmine\utils\Config;


class TaskX extends Task {

    public $pl;
    /** For Atomic Operation */
    public $counter; //Loop (goes until 180 -> reset)
    public $inter;   //Blocks certain vars
    public $task_list;

    public function __construct(Plugin $plugin) {
        $this->inter = FALSE;
        $this->counter = 0;
        $this->task_list = array();
        $this->pl = $plugin;
    }

    public function onRun(int $currentTick) :void {

        $this->inter = TRUE;

        if (!empty($this->task_list)) {
        foreach ($this->task_list as $n => $kc) {
                require $this->pl->getDataFolder()."storage.php";
                if ($kc[1] == "none") {
                    $this->task_list[$n][1] = $this->counter;
                    $data = $this->array_dict_push($data, $kc[0], $n);
                    file_put_contents($this->pl->getDataFolder()."storage.php", '<?php $data = ' . var_export($data, true) . ";") or die($sender->sendMessage("[ERROR] Ein Fehler ist aufgetreten, versuchen sie es erneut!"));
                } elseif ($kc[1] == $this->counter) {
                    unset($data[$kc[0]]);
                    unset($this->task_list[$n]);
                    file_put_contents($this->pl->getDataFolder()."storage.php", '<?php $data = ' . var_export($data, true) . ";") or die($sender->sendMessage("[ERROR] Ein Fehler ist aufgetreten, versuchen sie es erneut!"));
                }
            }
        } 
        $this->inter = FALSE;
        if ($this->counter == 180) {
            $this->counter = 0;
        } else {
            $this->counter = $this->counter + 5;
        }
    }

    public function cancel() {
        $this->getHandler()->cancel();
    }
    public function array_dict_push(array $ar, $key, $value) {

        $keys = array_keys($ar);
        if (in_array($key, $keys)) {return;}
        array_push($keys, $key);

        $values = array_values($ar);
        array_push($values, $value);

        $ar = array_combine($keys, $values);
        return $ar;
    }
}